from django.db import models

class Productos(models.Model):
    nomProducto = models.CharField(max_length=50)
    desProducto = models.CharField(max_length=200)
    catProducto = models.CharField(max_length=20)
    canProducto = models.PositiveIntegerField(default=True)
    preProducto = models.PositiveBigIntegerField(default=True)
    estProducto = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.id} - {self.nomProducto}'

class Order(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    operator_id = models.PositiveIntegerField()
    customer_id = models.PositiveIntegerField()

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Productos, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price = models.PositiveIntegerField()
    discount = models.PositiveIntegerField()
