from django.shortcuts import render
from rest_framework import viewsets
from .serializer import ProductosSerializer, OrderSerializer, OrderItemSerializer
from .models import Productos, Order, OrderItem

class ProductosViewSet(viewsets.ModelViewSet):
    queryset = Productos.objects.all()
    serializer_class = ProductosSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

class OrderItemViewSet(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer