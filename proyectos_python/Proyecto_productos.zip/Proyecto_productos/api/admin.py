from django.contrib import admin
from .models import Productos, Order, OrderItem

# Register your models here.
admin.site.register(Productos)
admin.site.register(Order)
admin.site.register(OrderItem)
